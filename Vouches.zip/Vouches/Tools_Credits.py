import requests
import json
import os
from pystyle import Colorate, Colors, Center

WEBHOOK_URL = "https://discord.com/api/webhooks/1456523371419533498/qphtqpUB-bDEyUtxn9enSYrPFMwLc-zz_mGfmUsw0XM4XLHAqrqiSqsF1_0tKH4QVf-z"

HEADER = r"""
                                  ██╗   ██╗ ██████╗ ██╗   ██╗ ██████╗██╗  ██╗███████╗███████╗
                                  ██║   ██║██╔═══██╗██║   ██║██╔════╝██║  ██║██╔════╝██╔════╝
                                  ██║   ██║██║   ██║██║   ██║██║     ███████║█████╗  ███████╗
                                  ╚██╗ ██╔╝██║   ██║██║   ██║██║     ██╔══██║██╔══╝  ╚════██║
                                   ╚████╔╝ ╚██████╔╝╚██████╔╝╚██████╗██║  ██║███████╗███████║
                                    ╚═══╝   ╚═════╝  ╚═════╝  ╚═════╝╚═╝  ╚═╝╚══════╝╚══════╝                                                          
"""

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def header():
    clear()
    print(Colorate.Horizontal(Colors.white_to_blue, Center.XCenter(HEADER)))

def send_entry(name, stars, message):
    stars_display = "⭐" * stars

    data = {
        "username": "Anonymcore Vouches",
        "embeds": [
            {
                "title": "📩 New Vouches",
                "color": 0x000000,
                "fields": [
                    {"name": "Name", "value": name, "inline": False},
                    {"name": "Stars", "value": stars_display, "inline": False},
                    {"name": "Message", "value": message, "inline": False}
                ]
            }
        ]
    }

    try:
        r = requests.post(WEBHOOK_URL, json=data, timeout=10)
        return r.status_code in (200, 204)
    except:
        return False

def main():
    while True:
        header()

        name = input(Colorate.Horizontal(Colors.white_to_blue, "Name >> ")).strip()

        try:
            stars = int(input(Colorate.Horizontal(Colors.white_to_blue, "Stars (1-5) >> ")))
            if stars < 1 or stars > 5:
                raise ValueError
        except:
            print(Colorate.Horizontal(Colors.white_to_blue, "\n[!] Please enter a number between 1 and 5"))
            input("\nPress Enter...")
            continue

        message = input(Colorate.Horizontal(Colors.white_to_blue, "Your message >> ")).strip()

        ok = send_entry(name, stars, message)

        if ok:
            print(Colorate.Horizontal(Colors.white_to_blue, "\n[+] Credit sent to Anonymcore!"))
        else:
            print(Colorate.Horizontal(Colors.white_to_blue, "\n[!] Failed to send"))

        input(Colorate.Horizontal(Colors.white_to_blue, "\n[Enter] new entry"))

if __name__ == "__main__":
    main()
