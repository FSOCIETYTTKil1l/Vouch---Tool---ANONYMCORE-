import os
import sys
import subprocess
import platform

REQUIRED = [
    "requests",
    "pystyle",
    "mss",
    "pillow"
]

def run(cmd):
    return subprocess.call(cmd, shell=True)

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def banner():
    clear()
    print("""
   ███████╗ ██████╗██╗   ██╗██╗   ██╗███████╗██████╗ 
   ██╔════╝██╔════╝╚██╗ ██╔╝██║   ██║██╔════╝██╔══██╗
   ███████╗██║      ╚████╔╝ ██║   ██║█████╗  ██████╔╝
   ╚════██║██║       ╚██╔╝  ██║   ██║██╔══╝  ██╔══██╗
   ███████║╚██████╗   ██║   ╚██████╔╝███████╗██║  ██║
   ╚══════╝ ╚═════╝   ╚═╝    ╚═════╝ ╚══════╝╚═╝  ╚═╝

           Credits INSTALLER
    """)

def check_python():
    try:
        subprocess.check_output("python --version", shell=True)
        return True
    except:
        return False

def install_packages():
    print("\n[~] Updating pip...")
    run("python -m pip install --upgrade pip")

    for pkg in REQUIRED:
        print(f"[~] Installing {pkg} ...")
        run(f"pip install {pkg}")

def create_launcher():
    if platform.system() == "Windows":
        with open("SCXVER.bat", "w") as f:
            f.write("python Scxver.py")
        print("[+] Created SCXVER.bat")

    else:
        with open("scxver.sh", "w") as f:
            f.write("#!/bin/bash\npython3 Scxver.py")
        run("chmod +x scxver.sh")
        print("[+] Created scxver.sh")

def main():
    banner()

    print("[~] Checking Python...")
    if not check_python():
        print("[!] Python not found. Install Python 3.10+ first.")
        input("Press Enter...")
        return

    print("[+] Python OK")

    install_packages()
    create_launcher()

    print("\n[✓] SCXVER successfully installed!")
    print("Start it with:")
    if platform.system() == "Windows":
        print("   SCXVER.bat")
    else:
        print("   ./scxver.sh")

    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()
